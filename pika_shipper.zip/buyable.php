<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">

<?php
include('header.php');
?>

<body id="page-top" class="index">

    <?php
    include('nav.php');
    ?>
	<section id="buyable" class="bg-light-gray">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 text-center" >
                    <h2 class="section-heading">MUA HỘ</h2>
                    <h3 class="section-subheading text-muted">♥ Chia sẻ về chuyến đi của bạn để chúng tôi liên hệ khi có người có nhu cầu ♥</h3>
                </div>
            </div>
			<div class="form-style-6" >
				<form action="#" method="get" style="padding-top: 0px;">
				<fieldset>
				<legend><span class="number">1</span>Thông tin chuyến đi</legend>
				<label for="currentplace">Đi từ*</label>
				<select name="currentplace" id="currentplace" class="medium gfield_select" tabindex="1">
					<option value="Nhật Bản">Nhật Bản</option>
					<option value="Hàn Quốc">Hàn Quốc</option>
					<option value="Pháp">Pháp</option>
					<option value="Mỹ">Mỹ</option>
					<option value="Hồng Kông">Hồng Kông</option>
					<option value="Thái Lan">Thái Lan</option>
					<option value="Úc">Úc</option>
					<option value="Anh">Anh</option>
					<option value="Singapore">Singapore</option>
					<option value="Đức">Đức</option>
					<option value="Ý">Ý</option>
					<option value="Tây Ban Nha">Tây Ban Nha</option>
					<option value="Nga">Nga</option>
					<option value="Canada">Canada</option>
				</select>
				<label>Đi đến*</label>
				<input type="text" name="destination" placeholder="Hồ Chí Minh, Hà Nội, Lào cai ..."></textarea>
                <label>Trọng lượng còn dư (kg)*</label>
                <input type="number" name="leweight"/>
				<label>Có thể mua</label>
				<input type="text" name="item" placeholder="(tự chọn): 100 BlackBerry Passport, iphone 7 ...">
				<input type="submit" value="CHIA SẺ CHUYẾN ĐI" />
				</form>
			</div>
    <?php
    include('footer.php');
    ?>

</body>

</html>
