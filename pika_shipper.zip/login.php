<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">

<?php
include('header.php');
?>

<body id="page-top" class="index">

  <?php
  include('nav.php');
  ?>
  <section id="login" class="bg-light-gray">
    <div class="container">
      <div class="row">
        <div class="col-lg-12 text-center">

          <div class="container">
            <div class="row">
             <p class="text-center"><a href="#" class="btn btn-primary btn-lg" role="button" data-toggle="modal" data-target="#login-modal">Button Login</a></p>


           </div>
         </div>
       </div>
     </div> </div>
     <!-- Begin LOGIN Form-->
     <!-----  login form  ---->
     <div class="login-form">
      <h1>Sign In</h1>
      <h2><a href="#">Create Account</a></h2>
      <form>
        <li>
          <input type="text" class="text" value="User Name" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'User Name';}" ><a href="#" class=" icon user"></a>
        </li>
        <li>
          <input type="password" value="Password" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Password';}"><a href="#" class=" icon lock"></a>
        </li>
        
        <div class ="forgot">
          <h3><a href="#">Forgot Password?</a></h3>
          <input type="submit" onclick="myFunction()" value="Sign In" > <a href="#" class=" icon arrow"></a>                                                                                                                                                                                                                                 </h4>
        </div>
      </form>
    </div>
    <!--  End login form  -->
    <!-- END LOGIN Form-->
    <script language="javascript">
    $('#div-forms').submit(function ()
    {
            // Xóa trắng thẻ div show lỗi
            $('#login_error').html('');

            var email = $('#login_email').val();
            var password = $('#login_password').val();
            // Kiểm tra dữ liệu có null hay không

            
            // Nếu bạn thích có thể viết thêm hàm kiểm tra định dang email
            if ($.trim(email) == ''||$.trim(password) == '')
            {
              $('#login_error').html('');
              $('#login_error').html('Vui lòng nhập đầy đủ thông tin');
              return false;
            }
            // ở đây tôi làm chú yêu chỉ cách dùng ajax nên sẽ ko đề cập tới,
            // vì sợ bài dài sẽ rối

            $.ajax({
              url : 'loginsubmit.php',
              type : 'post',
              dataType : 'json',
              data : {
                email : email,
                password : password
              },
              success : function (result)
              {
                    // Kiểm tra xem thông tin gửi lên có bị lỗi hay không
                    // Đây là kết quả trả về từ file do_validate.php
                    
                    var html = '';
                    
                    // Lấy thông tin lỗi email
                    if ($.trim(result.email) != ''){
                      html += result.email;
                    }

                    // Cuối cùng kiểm tra xem có lỗi không
                    // Nếu có thì xuất hiện lỗi
                    if (html != ''){
                     $('#login_error').html('Email hoặc mật khẩu không chính xác');
                   }
                   else {
                    window.location.href = 'index.php';
                    window.alert("Login Succesfully!");
                  }
                }
              });

return false;
});

</script> 

<?php
include('footer.php');
?>
</body>

</html>
